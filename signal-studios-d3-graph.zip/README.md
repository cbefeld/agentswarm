# CENNA Dashboards

A modern dashboard application for data visualization and analytics.

## Overview

CENNA Dashboards provides an interactive platform for creating, managing, and visualizing data dashboards with real-time updates and customizable components.

## Features

- Interactive data visualizations
- Real-time data updates
- Customizable dashboard layouts
- Responsive design
- Dark/Light theme support

## Getting Started

1. Clone the repository
2. Open `index.html` in your browser
3. Start building your dashboards!

## Technologies

- HTML5
- CSS3
- JavaScript
- D3.js (for data visualizations)

## Project Structure

```
CENNA-Dashboards/
├── index.html          # Main application
├── styles.css          # Styling
├── script.js           # Main JavaScript logic
└── README.md           # This file
```

## License

MIT License 